#!/usr/bin/env python

from . import hashable_counter
from . import objects
from . import morphisms

name = "multihypergraph"